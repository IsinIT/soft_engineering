# Starter — рабочая папка студента

Здесь лежат исходники приложения **без** Docker-файлов. По ходу практической работы
вы создадите:

```
starter/
├── backend/
│   ├── .dockerignore            ← шаг 3.1
│   ├── Dockerfile.naive         ← шаг 2.1 (антипример для сравнения)
│   └── Dockerfile               ← шаг 3.2 (multi-stage)
├── frontend/
│   ├── .dockerignore            ← шаг 6.1
│   ├── nginx/default.conf.template  ← шаг 5.1
│   └── Dockerfile               ← шаг 6.2 (multi-stage)
├── .env.example / .env          ← шаг 7.1
└── docker-compose.yml           ← шаг 7.2
```

Критерий приёмки: `docker compose up --build` → <http://localhost:8080>.
