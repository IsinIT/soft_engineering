using Microsoft.EntityFrameworkCore;
using TodoApi.Data;
using TodoApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Строка подключения берётся из конфигурации.
// В контейнере её передаёт docker-compose через переменную окружения
// ConnectionStrings__Default (двойное подчёркивание = вложенный ключ).
var connectionString = builder.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("Не задана строка подключения ConnectionStrings:Default");

builder.Services.AddDbContext<AppDbContext>(o => o.UseNpgsql(connectionString));

// CORS нужен только при локальной разработке без nginx (ng serve на :4200).
// В Docker фронт и API живут на одном origin за nginx, и CORS не требуется.
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

app.UseCors();

// ---------- Инициализация БД с повторными попытками ----------
// Даже при depends_on: service_healthy полезно уметь переждать недоступность БД.
await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    for (var attempt = 1; ; attempt++)
    {
        try
        {
            await db.Database.EnsureCreatedAsync();
            await db.SeedAsync();
            logger.LogInformation("База данных готова (попытка {Attempt})", attempt);
            break;
        }
        catch (Exception ex) when (attempt < 10)
        {
            logger.LogWarning("БД недоступна ({Message}). Повтор через 3 с…", ex.Message);
            await Task.Delay(TimeSpan.FromSeconds(3));
        }
    }
}

// ---------- Эндпоинты ----------
app.MapGet("/health", () => Results.Ok(new { status = "ok", time = DateTime.UtcNow }));

app.MapGet("/api/info", () => Results.Ok(new
{
    service = "TodoApi",
    framework = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    machine = Environment.MachineName // в контейнере это ID контейнера
}));

var todos = app.MapGroup("/api/todos");

todos.MapGet("/", async (AppDbContext db) =>
    await db.Todos.OrderBy(t => t.Id).ToListAsync());

todos.MapGet("/{id:int}", async (int id, AppDbContext db) =>
    await db.Todos.FindAsync(id) is { } t ? Results.Ok(t) : Results.NotFound());

todos.MapPost("/", async (TodoInput input, AppDbContext db) =>
{
    if (string.IsNullOrWhiteSpace(input.Title))
        return Results.BadRequest(new { error = "Title обязателен" });

    var item = new TodoItem { Title = input.Title.Trim(), IsDone = input.IsDone };
    db.Todos.Add(item);
    await db.SaveChangesAsync();
    return Results.Created($"/api/todos/{item.Id}", item);
});

todos.MapPut("/{id:int}", async (int id, TodoInput input, AppDbContext db) =>
{
    var item = await db.Todos.FindAsync(id);
    if (item is null) return Results.NotFound();
    item.Title = input.Title.Trim();
    item.IsDone = input.IsDone;
    await db.SaveChangesAsync();
    return Results.Ok(item);
});

todos.MapDelete("/{id:int}", async (int id, AppDbContext db) =>
{
    var item = await db.Todos.FindAsync(id);
    if (item is null) return Results.NotFound();
    db.Todos.Remove(item);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

app.Run();
