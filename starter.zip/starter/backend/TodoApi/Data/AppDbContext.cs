using Microsoft.EntityFrameworkCore;
using TodoApi.Models;

namespace TodoApi.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<TodoItem> Todos => Set<TodoItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TodoItem>(e =>
        {
            e.ToTable("todos");
            e.Property(t => t.Title).HasMaxLength(200).IsRequired();
        });
    }

    /// <summary>
    /// Начальные данные — чтобы после `docker compose up` на странице сразу что-то было.
    /// Заполняем через обычный INSERT (а не HasData с явными Id), чтобы
    /// последовательность identity в PostgreSQL не «отставала» от данных.
    /// </summary>
    public async Task SeedAsync()
    {
        if (await Todos.AnyAsync()) return;
        Todos.AddRange(
            new TodoItem { Title = "Написать multi-stage Dockerfile для бэкенда", IsDone = true },
            new TodoItem { Title = "Собрать Angular и отдать его через nginx" },
            new TodoItem { Title = "Поднять весь стек одной командой docker compose up" });
        await SaveChangesAsync();
    }
}
