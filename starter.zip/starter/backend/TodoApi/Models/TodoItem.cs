namespace TodoApi.Models;

/// <summary>Задача из списка дел.</summary>
public class TodoItem
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public bool IsDone { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>DTO для создания/обновления задачи.</summary>
public record TodoInput(string Title, bool IsDone = false);
