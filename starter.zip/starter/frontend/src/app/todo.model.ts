export interface Todo {
  id: number;
  title: string;
  isDone: boolean;
  createdAt: string;
}

export interface ApiInfo {
  service: string;
  framework: string;
  os: string;
  machine: string;
}
