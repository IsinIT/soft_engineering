import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TodoService } from './todo.service';
import { ApiInfo, Todo } from './todo.model';

@Component({
  selector: 'app-root',
  imports: [FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  private readonly api = inject(TodoService);

  todos = signal<Todo[]>([]);
  info = signal<ApiInfo | null>(null);
  error = signal<string | null>(null);
  loading = signal(true);
  newTitle = '';

  ngOnInit(): void {
    this.reload();
    this.api.info().subscribe({ next: i => this.info.set(i), error: () => {} });
  }

  reload(): void {
    this.loading.set(true);
    this.api.getAll().subscribe({
      next: list => { this.todos.set(list); this.error.set(null); this.loading.set(false); },
      error: e => { this.error.set(`API недоступен (${e.status || 'нет ответа'})`); this.loading.set(false); }
    });
  }

  add(): void {
    const title = this.newTitle.trim();
    if (!title) return;
    this.api.add(title).subscribe(t => { this.todos.update(l => [...l, t]); this.newTitle = ''; });
  }

  toggle(t: Todo): void {
    this.api.update({ ...t, isDone: !t.isDone })
      .subscribe(u => this.todos.update(l => l.map(x => x.id === u.id ? u : x)));
  }

  remove(t: Todo): void {
    this.api.remove(t.id).subscribe(() => this.todos.update(l => l.filter(x => x.id !== t.id)));
  }

  get doneCount(): number { return this.todos().filter(t => t.isDone).length; }
}
