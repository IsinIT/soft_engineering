import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiInfo, Todo } from './todo.model';

/**
 * Обращаемся к API по ОТНОСИТЕЛЬНОМУ пути /api.
 * - в Docker запрос попадает в nginx, который проксирует его в контейнер backend;
 * - при `npm start` его проксирует dev-сервер Angular (proxy.conf.json).
 * Благодаря этому один и тот же собранный бандл работает в любом окружении.
 */
@Injectable({ providedIn: 'root' })
export class TodoService {
  private readonly http = inject(HttpClient);
  private readonly base = '/api/todos';

  getAll(): Observable<Todo[]> { return this.http.get<Todo[]>(this.base); }
  add(title: string): Observable<Todo> { return this.http.post<Todo>(this.base, { title }); }
  update(t: Todo): Observable<Todo> {
    return this.http.put<Todo>(`${this.base}/${t.id}`, { title: t.title, isDone: t.isDone });
  }
  remove(id: number): Observable<void> { return this.http.delete<void>(`${this.base}/${id}`); }
  info(): Observable<ApiInfo> { return this.http.get<ApiInfo>('/api/info'); }
}
